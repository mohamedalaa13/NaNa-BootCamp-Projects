from helper import validate_user_input
import logging

user_input = ""
while user_input != "stop":
    user_input = input("Enter the Number of Days: \n")
    days_unit = user_input.split(":")
    days_unit_dictionary = {"days": days_unit[0], "unit": days_unit[1]}
    print(days_unit_dictionary)
    validate_user_input(days_unit_dictionary)



