def days_to_unit(num_of_days, unit_name):
    if unit_name == "hours":
        return f"{num_of_days} days equals {num_of_days * 24} {unit_name}"
    elif unit_name == "minutes":
        return f"{num_of_days} days equals {num_of_days * 24 * 60} {unit_name}"
    elif unit_name == "seconds":
        return f"{num_of_days} days equals {num_of_days * 24 * 60 * 60} {unit_name}"
    else:
        return "Wrong Unit!!!!!"


def validate_user_input(days_unit_dictionary):
    try:
        user_input_number = int(days_unit_dictionary["days"])
        user_input_unit = str(days_unit_dictionary["unit"])
        if user_input_number > 0:
            calculated_value = days_to_unit(user_input_number, user_input_unit)
            print(calculated_value)
        elif user_input_number == 0:
            print("You entered Zero")
        else:
            print("You entered a Negative Number!!")
    except ValueError:
        print("Please Enter a Number!")