from datetime import datetime

target = input("Enter your Deadline separated by : \n")
input_list = target.split(":")
goal = input_list[0]
deadline = input_list[1]

# User's Deadline
deadline_date = datetime.strptime(deadline, "%d.%m.%Y")
# Today's Date
today_date = datetime.today()

time_till = deadline_date - today_date
print(f"Time till Goal {goal} is {time_till}")
